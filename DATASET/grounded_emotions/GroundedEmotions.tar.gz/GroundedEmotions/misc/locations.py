# File name: locations.py
# Author: Vicki Liu

locations = set([
'Los Angeles, CA',
'Manhattan, NY',
'Chicago, IL',
'San Francisco, CA',
'Washington, DC',
'Denver, CO',
'Brooklyn, NY',
'Houston, TX',
'Philadelphia, PA',
'Phoenix, AZ',
'San Diego, CA',
'Portland, OR',
'Miami, FL',
'Queens, NY',
'Dallas, TX',
'Miami Beach, FL',
'Raleigh, NC',
'Austin, TX',
'Seattle, WA',
'Kansas City, MO',
'Atlanta, GA'
 ])

